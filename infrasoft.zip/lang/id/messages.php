<?php
return [
    'hero_title' => 'Solusi Server & Jaringan Terpercaya',
    'hero_subtitle' => 'Infrasoft hadir untuk membantu bisnis Anda dengan layanan IT, server, dan jaringan yang handal.',
    'cta_free_consult' => 'Konsultasi Gratis',
    'cta_services' => 'Lihat Layanan',
    'services_title' => 'Layanan Kami',
    'about_title' => 'Tentang Infrasoft',
    'contact_title' => 'Hubungi Kami',
];
