<?php
return [
    'hero_title' => 'Trusted Server & Network Solutions',
    'hero_subtitle' => 'Infrasoft helps your business with reliable IT, server, and networking services.',
    'cta_free_consult' => 'Free Consultation',
    'cta_services' => 'View Services',
    'services_title' => 'Our Services',
    'about_title' => 'About Infrasoft',
    'contact_title' => 'Contact Us',
];
