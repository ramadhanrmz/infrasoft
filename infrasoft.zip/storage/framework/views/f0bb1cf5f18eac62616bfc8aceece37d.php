

<?php $__env->startSection('title', 'Layanan'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-20 max-w-7xl mx-auto px-6">
    <h2 class="text-3xl font-bold text-center mb-12">Layanan Kami</h2>
    <div class="grid md:grid-cols-3 gap-8">
        <div class="bg-white shadow-lg p-6 rounded-xl hover:shadow-xl transition">
            <h3 class="text-xl font-semibold mb-4">Manajemen Server</h3>
            <p>Kami menyediakan instalasi, konfigurasi, dan maintenance server untuk kebutuhan bisnis Anda.</p>
        </div>
        <div class="bg-white shadow-lg p-6 rounded-xl hover:shadow-xl transition">
            <h3 class="text-xl font-semibold mb-4">Jaringan & Infrastruktur</h3>
            <p>Desain dan implementasi jaringan LAN, WAN, serta solusi infrastruktur IT yang aman dan efisien.</p>
        </div>
        <div class="bg-white shadow-lg p-6 rounded-xl hover:shadow-xl transition">
            <h3 class="text-xl font-semibold mb-4">Cloud & Virtualisasi</h3>
            <p>Membantu migrasi ke cloud, virtualisasi server, dan solusi modern untuk efisiensi perusahaan Anda.</p>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\infrasoft\resources\views/services.blade.php ENDPATH**/ ?>