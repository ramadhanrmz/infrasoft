<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 80" class="h-12">
  <!-- Node network -->
  <circle cx="40" cy="40" r="30" fill="#2563eb" opacity="0.9"/>
  <circle cx="40" cy="15" r="6" fill="white"/>
  <circle cx="65" cy="40" r="6" fill="white"/>
  <circle cx="40" cy="65" r="6" fill="white"/>
  <circle cx="15" cy="40" r="6" fill="white"/>
  <line x1="40" y1="15" x2="65" y2="40" stroke="white" stroke-width="2"/>
  <line x1="65" y1="40" x2="40" y2="65" stroke="white" stroke-width="2"/>
  <line x1="40" y1="65" x2="15" y2="40" stroke="white" stroke-width="2"/>
  <line x1="15" y1="40" x2="40" y2="15" stroke="white" stroke-width="2"/>
  <!-- Text -->
  <text x="90" y="50" font-family="Arial, sans-serif" font-size="28" font-weight="bold" fill="#1e3a8a">
    Infrasoft
  </text>
</svg>
<?php /**PATH C:\laragon\www\infrasoft\resources\views/partials/logo.blade.php ENDPATH**/ ?>