

<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>
<section class="h-screen flex flex-col justify-center items-center bg-gradient-to-r from-blue-600 to-indigo-700 text-white text-center px-4">
    <h1 class="text-5xl font-extrabold">Solusi Server & Jaringan Terpercaya</h1>
    <p class="mt-4 text-lg max-w-2xl">
        Infrasoft hadir untuk membantu bisnis Anda dengan layanan IT, server, dan jaringan yang handal.
    </p>
    <a href="<?php echo e(url('/contact')); ?>" class="mt-6 px-6 py-3 bg-white text-blue-700 font-semibold rounded-lg shadow hover:bg-gray-200">
        Konsultasi Gratis
    </a>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\infrasoft\resources\views/home.blade.php ENDPATH**/ ?>