

<?php $__env->startSection('title', 'Kontak'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-20 max-w-4xl mx-auto px-6">
    <h2 class="text-3xl font-bold text-center mb-8">Hubungi Kami</h2>
    <form action="#" method="POST" class="bg-white shadow-lg rounded-xl p-8 space-y-6">
        <input type="text" placeholder="Nama Anda" class="w-full p-3 border rounded-lg focus:ring focus:ring-blue-300" required>
        <input type="email" placeholder="Email Anda" class="w-full p-3 border rounded-lg focus:ring focus:ring-blue-300" required>
        <textarea placeholder="Pesan Anda" class="w-full p-3 border rounded-lg focus:ring focus:ring-blue-300" rows="5" required></textarea>
        <button type="submit" class="w-full py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700">
            Kirim Pesan
        </button>
    </form>

    <div class="text-center mt-6">
        <a href="https://wa.me/6281234567890" target="_blank" 
           class="inline-block px-6 py-3 bg-green-500 text-white rounded-lg shadow hover:bg-green-600">
           Chat via WhatsApp
        </a>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\infrasoft\resources\views/contact.blade.php ENDPATH**/ ?>