

<?php $__env->startSection('title', 'Tentang Kami'); ?>

<?php $__env->startSection('content'); ?>
<section class="bg-gray-100 py-20 px-6">
    <div class="max-w-5xl mx-auto text-center">
        <h2 class="text-3xl font-bold mb-6">Tentang Infrasoft</h2>
        <p class="text-lg leading-relaxed">
            Infrasoft adalah penyedia layanan IT perorangan yang bergerak di bidang server dan jaringan. 
            Kami berkomitmen memberikan solusi terbaik dengan dukungan teknis berpengalaman untuk mendukung pertumbuhan bisnis Anda.
        </p>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\infrasoft\resources\views/about.blade.php ENDPATH**/ ?>